type IValidatorFunction<Body> = (data: Body) => Body;

export default IValidatorFunction;
